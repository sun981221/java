package com.example.demo;

import lombok.Data;

import java.io.Serializable;

@Data
public class RowData implements Serializable {
    private String row1;
    private String row2;
    private String row3;
    private String row4;
    private String row5;
    private String row6;
    private String row7;
    private String row8;
    private String row9;
    private String row10;
}